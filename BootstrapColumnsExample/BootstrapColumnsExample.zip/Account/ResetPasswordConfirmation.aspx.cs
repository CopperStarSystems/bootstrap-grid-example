﻿using System.Web.UI;

namespace BootstrapColumnsExample.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}